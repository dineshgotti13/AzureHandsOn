az account show;
MYSQL_MIN=$1
RG_NAME=$2
KV_NAME=$3
KEYNAME=$4
STORAGE_DIAG=$5
ENV=$6
LAW_NAME=$7
ADMIN_PAS=$(az keyvault secret show --name adminsqlmipass --vault-name devops-kv-15884 --query value -o tsv)
echo "$MYSQL_MIN $RG_NAME $KV_NAME $ENV"

echo "$ENV"
ls ../Layers/$ENV/MISQL.json
ls ../Layers/$ENV/parms.json
#echo "az sql mi create -name "$MYSQL_MIN" --resource-group $RG_NAME --admin-password "sqlMIinstExactAgent20201012" --admin-user sqlmiadmin --subnet $SUBBNET--assign-identity --capacity 4 --storage 32GB --edition GeneralPurpose --family Gen5 --backup-storage-redundancy Local --license-type LicenseIncluded --minimal-tls-version  1.2 --proxy-override  Proxy --public-data-endpoint-enabled false"
#az sql mi create --name "$MYSQL_MIN" --resource-group $RG_NAME --subnet $SUBBNET --admin-password $ADMIN_PAS --admin-user sqlmiadmin --assign-identity --capacity 4 --storage 32GB --edition GeneralPurpose --family Gen5 --license-type LicenseIncluded --minimal-tls-version  1.2 --proxy-override  Proxy --public-data-endpoint-enabled false
az group deployment create --resource-group $RG_NAME --template-file ../Layers/$ENV/MISQL.json --parameters ../Layers/$ENV/parms.json
obbjectid=$(az sql mi show -g $RG_NAME  -n $MYSQL_MIN --query [identity.principalId] -o tsv)
az keyvault key create --name $KEYNAME --vault-name $KV_NAME --protection software 
keyid=$(az keyvault key show -n $KEYNAME --vault-name $KV_NAME --query [key.kid] -o tsv)
az keyvault set-policy --name  $KV_NAME  --object-id $obbjectid --resource-group $RG_NAME --key-permissions wrapKey unwrapKey get
az sql mi key create --kid $keyid --managed-instance $MYSQL_MIN --resource-group  $RG_NAME
az sql mi tde-key set --server-key-type AzureKeyVault --kid $keyid --managed-instance $MYSQL_MIN --resource-group  $RG_NAME
MIRES_ID=$(az resource list --name $MYSQL_MIN --query [].id -o tsv)
STRES_ID=$(az resource list --name $STORAGE_DIAG --query [].id -o tsv)
LAWRES_ID=$(az resource list --name $LAW_NAME --query [].id -o tsv)
az monitor diagnostic-settings create  --name $MYSQL_MIN-Diagnostics --resource $MIRES_ID --logs    '[{"category": "ResourceUsageStats","enabled": true},{"category": "DevOpsOperationsAudit","enabled": true},{"category": "SQLSecurityAuditEvents","enabled": true}]' --metrics '[{"category": "AllMetrics","enabled": true}]' --storage-account $STRES_ID --workspace $LAWRES_ID



