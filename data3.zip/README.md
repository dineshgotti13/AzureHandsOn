# Pre-requisites
- DevOps Onboarding Services (contains storage account for state)
- Separate service connections to required subscriptions
- A container in the state storage account
- ADO agent MSI has storage account key operator role on the storage where state is saved
#Understanding Layers
 The Layers are the core modules to deploy services in azure. The layer requires a .tfvars file (typically values for configuring the service) which will deploy the services in azure. The tfvar files are stored in [kits](./kits). Each layer contains pipeline to generate artifact for layer and push it azure artifactory which will be triggered from its perpective environment [pipeline](./kits/jumpstart-windows-vm/Pipelines/Pipeline.dev_eastus2.yaml) file.
##constructing layer
To create layer you need to create directory for the service ex: aks. The layer should consists of following files and directory.
- Pipelines/pipeline.yaml
<br> The pipeline.yaml file consists of sequence of tasks to generate artifact and push to azure artifact with the name of layer.
To create new 'pipeline.yaml' file for layer copy the code and replace 'aks' with proper layer name(case sensitive).
````yaml
name: layer-aks-$(Date:yyyyMMdd).$(Rev:rr)

trigger:
  batch: true
  branches:
    include:
    - master
    - users/*
  paths:
    include:
      - /layers/aks
      - /scripts
    exclude: 
      - /**/*.md
      - /.attachments

variables:
  - name: system.debug 
    value: true

pool: custom_vmss

steps:
- bash: cp -v $(System.DefaultWorkingDirectory)/scripts/*.sh '$(System.DefaultWorkingDirectory)/layers/aks'
- bash: |
    escapedCommitMessage=$(printf "%q" "$(Build.SourceVersionMessage)") 2> /dev/null

    if [[ $escapedCommitMessage == "MAJOR" ]]
    then
      echo "##vso[task.setvariable variable=versionOption]major"
      echo "in major loop"
    elif [[ $escapedCommitMessage == "MINOR" ]]
    then
      echo "##vso[task.setvariable variable=versionOption]minor"
      echo "in minor loop"
    else
      echo "##vso[task.setvariable variable=versionOption]patch"
      echo "in patch loop"
    fi

- task: UniversalPackages@0
  displayName: Publish Layer to Azure Artifacts Gallery
  inputs:
    command: 'publish'
    publishDirectory: '$(System.DefaultWorkingDirectory)/layers/aks'
    feedsToUsePublish: 'internal'
    vstsFeedPublish: '06a79111-55ca-40be-b4ff-0982bd47e87c/e76d08fd-dd42-4b5c-bc0b-01ff3f70f598'
    vstsFeedPackagePublish: 'layer-aks'
    versionOption: 'patch'
````
- authentication.tf <br> The file contains variable for required for authenticate to the cloud provider.

```yaml

variable "subscription_id" {
  description = "Azure subscription Id."
}

variable "tenant_id" {
  description = "Azure tenant Id."
}

variable "client_id" {
  description = "Azure service principal application Id"
}

variable "client_secret" {
  description = "Azure service principal application Secret"
}
```
- main.tf <br> The file contains code to deploy the service to the azure.
- output.tf <br> The file outputs the values which will  be consumed by the another layer when this layer is invoked using remote state import.
- provider.tf <br> The file contains cloud provider details to authenticate to azure.
- variables.tf <br> The file contails variables required for cloud service to provision.
 
#Understanding Kits
The kits can be reffred to as services deployment for our requirement. It contains [Layers](./kits/jumpstart-windows-vm/Layers) for each region and tfvars file defined with values. The Layer must contains environment-name_region. each layer must contain auto.tfvars for each layer.
The Layer also contains Pipelines folder which deploys layer and its dependecies.
### Pipelines
#### Layers.yaml
[Layers.yaml](./kits/jumpstart-windows-vm/Pipelines/Layers.yaml) is template file which contains stages to plan and deploy the terraform layer.
<<<<<<< HEAD
The Template will create stage layer_name-plan which contains jobs. The first job will download the artifact created by [layers](./layers/aks/Pipelines/Pipeline.yaml) followed by that preparing layer to import terraform state into the current layer by executing [layer.sh](./scripts/layers.sh). The next job is to plan terraform execution by executing [terraformplan.sh](./scripts/terraformplan.sh).
=======
The Template will create stage layer_name-plan which contains jobs. The first job will download the artifact created by [layers](./layers/aks/Pipelines/Pipeline.yaml) followed by that prepaparing layer to import terraform state into the current layer by execyuring [layer.sh](./scripts/layers.sh). The next job is to plan terraform execution by executing [terraformplan.sh](./scripts/terraformplan.sh).
>>>>>>> ae86f9e699c0f99a863ffa65b13b63138eb4c0e7
This step is continued until all dependent layers are excuted from [Pipeline.dev_westus2.yaml](./kits/jumpstart-windows-vm/Pipelines/Pipeline.dev_eastus2.yaml).
The next stage is to apply the plan which is executed in the earlier stage.
####Pipeline.dev_eastus2.yaml 
The pipeline references to template Layers.yaml with parameters as layers with dependencies as shown below. it also references to the [variable file](./kits/jumpstart-windows-vm/Pipelines/Variables.dev_eastus2.yaml) 
```yaml
<<<<<<< HEAD
stages:
  - template: ./Layers.yaml
    parameters:
      environment: demo

      getImageLayers: virtualmachine
      projectName: ${{ variables.projectName }}
      pipelineId: ${{ variables.pipelineId }}
      runId: $(resources.pipeline.image-source.runID)
      preferTriggeringPipeline: ${{ variables.preferTriggeringPipeline }}
      downloadPath: ${{ variables.downloadPath }}

      layers:
        - name: resourcegroup
          type: resourcegroup
          version: "2.0.47"
          skip: false
          dependencies:
            start: start

        - name: networking
          type: networking
          version: "2.0.54"
          skip: false
          dependencies:
            resourcegroup: resourcegroup

        - name: loganalytics
          type: loganalytics
          version: "2.0.50"
          skip: false
          dependencies:
            resourcegroup: resourcegroup


=======
variables:
  - template: Variables.yaml

stages:
  - template: ./Layers.yaml
    parameters:
      environment: dev_eastus2
      layers:
        - name: resourcegroup
          version: "*"
          dependencies:
            start: start
        - name: networking
          version: "2.0.25"
          dependencies:
             resourcegroup: resourcegroup
        - name: applicationinsights
          version: "2.0.23"
          dependencies:
            resourcegroup: resourcegroup
        - name: loganalytics
          version: "2.0.26"
          dependencies:
            resourcegroup: resourcegroup

>>>>>>> ae86f9e699c0f99a863ffa65b13b63138eb4c0e7
```
The dependent layer will also executed during execution of each layer.
The below are the parameters for Layer.yaml
- name : Name of the layer, it should be same name as [layers](./layers/aks)
<<<<<<< HEAD
- type : Display Name of the artifact
- version: Current version of the layer, the layer version will get change if the any modification to the core layer. to download new version artifact we should use '*' as version value.
- skip : skips the deploymnet of the layer if set 'true'.
=======
- version: Current version of the layer, the layer version will get change if the any modification to the core layer. to download new version artifact we should use '*' as version value.
>>>>>>> ae86f9e699c0f99a863ffa65b13b63138eb4c0e7
- dependencies: The default dependency is start: start which will trigger start job to trigger pipeline. This dependency has to explicitly mentioned if no dependency for the layer exists.
The dependencies are mentioned as below.

```yaml
          dependencies:
            windowsvirtualmachine: windowsvirtualmachine
            privatelinkservice: privatelinkservice
            loadbalancer: loadbalancer
```
### Layers
The layer contains environment wise tfvars file which contains desired values required for layer to deploy the Module. The layer tfvars should be named as var-<layername>.auto.tfvars
#### ApplicationInsigts 
#####`var-applicationinsights.auto.tfvars`
The application insight is service offered by Azure and configured with [applicationinsights layer](./layers/applicationinsights). The Layer has variable file for which values has to mentioned in [var-applicationinsights.auto.tfvars](./kits/jumpstart-windows-vm/Layers/dev_eastus2/var-applicationinsights.auto.tfvars) file.<br>
Variable File
```hcl-terraform
variable "resource_group_name" {
  type        = string
  description = "(Required) The name of the resource group in which to create the Application Insights component."
}

variable "app_insights_additional_tags" {
  type        = map(string)
  description = "A mapping of tags to assign to the resource"
  default     = {}
}

# -
# - Application Insights
# -
variable "application_insights" {
  type = map(object({
    name                                  = string
    application_type                      = string
    retention_in_days                     = number
    daily_data_cap_in_gb                  = number
    daily_data_cap_notifications_disabled = bool
    sampling_percentage                   = number
    disable_ip_masking                    = bool
  }))
  description = "Map containing Application Insights details"
  default     = {}
}

############################
# State File
############################ 
variable ackey {
  description = "Not required if MSI is used to authenticate to the SA where state file is"
  default     = null
}
```
<br>tfvars file example<br>
```hcl-terraform
resource_group_name = "ccfsbs-eastus2-nprd-rg"

application_insights = {
  appinsight1 = {
    name                                  = "wjsk-application-insights-7212020" # <"application_insights_name">
    application_type                      = "web"                       # <"application_insights_type">
    retention_in_days                     = 60                          # <"application_insights_retention_period_in_days"
    daily_data_cap_in_gb                  = null                        # <"application_insights_daily_data_volume_cap_in_gb"
    daily_data_cap_notifications_disabled = null                        # <true | false>
    sampling_percentage                   = null                        # <"appication_insights_telemetry_data_percentage">
    disable_ip_masking                    = null                        # <true | false>
  }
}

app_insights_additional_tags = {
  iac = "Terraform"
  env = "UAT"
}
```

# Minimum variables to change to deploy
Ideally all variable values in /layers/env should be reviewed to enusre they meet your application requirements.  Due to the fact that some values are used in different files, it is recommended to find and replace in all files in the folder to ensure you update all references.  To deploy this kit on first attempt, the following changes are required:

## Variables.yaml
1. motsId
2. agent_pool

## Pipeline.dev.yaml
1. Remove resources block where noted if not planning to use Image Builder on first deployment

## var-resourcegroup.auto
1. name
2. location

## var-networking.auto.tfvars
1. virtual_networks.wjsk-vnetfirst.name
2. virtual_networks.wjsk-vnetfirst.address_space
3. virtual_networks.wjsk-vnetfirst.dns_servers
4. subnets.windows-client-infra-snet.vnet_key
5. subnets.windows-client-infra-snet.name
6. subnets.windows-client-infra-snet.address_prefixes
7. subnets.windows-client-infra-snet.pe_enable set to true/false as per requirement.
8. network_security_groups.nsg1.name
9. network_security_groups.nsg1.security_rules.name
10. network_security_groups.nsg1.security_rules.description
11. network_security_groups.nsg1.security_rules.priority
12. network_security_groups.nsg1.security_rules.direction
13. network_security_groups.nsg1.security_rules.access
14. network_security_groups.nsg1.security_rules.source_port_range
15. network_security_groups.nsg1.security_rules.destination_port_range
16. network_security_groups.nsg1.security_rules.source_address_prefix
17. network_security_groups.nsg1.security_rules.destination_address_prefix

## var-storage.auto.tfvars
1. storage_accounts.sa1.name and all references (find and replace)

## var-keyvault.auto.tfvars
1. name
2. diagnostics_storage_account_name - Must match what was changed in var-storage.auto.tfvars

## var-privateendpoints.auto.tfvars
1. private_endpoints.pe1.resource_name - Must match what was changed in var-keyvault.auto.tfvars
2. ado_pe_kv_name - Needed to create a PE for the ADO agent to access the deployed KV
3. ado_resource_group_name - Needed to create a PE for the ADO agent to access the deployed KV
4. ado_vnet_name - Needed to create a PE for the ADO agent to access the deployed KV
5. ado_subnet_name - Needed to create a PE for the ADO agent to access the deployed KV
6. ado_subscription_id - Needed to create a PE for the ADO agent to access the deployed KV

## var-privatednszone.auto
1. dns_zone_name
2. vnet_name - Must match with the name of 'virtual_networks' in var-networking.auto.tfvars. 

## var-privatednsarecord.auto.tfvars
1. a_record_name
2. dns_zone_name
3. private_endpoint_name 
                                     
## var-nsgflowlogs.auto.tfvars
1. flow_logs.flowlog1.storage_account_name
 
## var-loganalytics.auto.tfvars
1. name

## var-applicationinsights.auto
1. name

## var-applicationgateway.auto.tfvars
1. diagnostics_storage_account_name
2. key_vault_resource_group - App gateway requires a certificate on an existing keyvault
3. key_vault_name - App gateway requires a certificate on an existing keyvault

## var-vnetpeering.auto.tfvars
1. destination_vnet_name - Peering requires destination vnet name which would be AD vnet name.
2. destination_vnet_rg - AD resource group for vnet peering has to be given here.
3. source_vnet_name - vnet which needs to be paired with AD.
4. source_vnet_rg - resource group of the vnet which needs to be peered with AD.
5. destination_vnet_subscription_id - subscription of the destination vnet.

## var-domainjoin.auto.tfvars
1. key_vault_name - name of the Key vault which holds secrets used for domain join.
2. key_vault_rg_name - resources group of the key vault.
3. key_vault_subscription_id - Provide the subscription of the key vault.
4. secret_name - Name of the secrete in Keyvault.

## var-windowsvirtualmachine.auto.tfvars
1. vm_prefix 
2. subnet_name