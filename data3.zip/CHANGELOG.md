# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## [1.3.0] - 2020-09-28
- Updated the domain join layer values to use the central key vault [200957](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/200957)

## [1.3.0] - 2020-09-28

### Changed
- Updated the domainjoin layer to 0.4.0 which uses msi to retrieve the Key Vault Secret.

## [1.2.0] - 2020-09-15

### Changed

- Resolve Multiple Layer Instance Issue In Layer.sh [#193412](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/193412)

## [1.1.0] - 2020-09-07

### Added

- WJSK: Implement custom extension script [#173452](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/173452)
- WJSK: Implement Back up recovery [#173455](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/173455)
- WJSK: Implement Load balancer [#173454](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/173454)
