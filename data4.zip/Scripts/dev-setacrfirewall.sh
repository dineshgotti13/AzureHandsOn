#!/bin/bash

# Workaround to add outbound IPs of App service into the Allowed list of the ACR firewall 
# so that App service containerized webapps can pull images from the Azure Container registry.
# This is for connectivity only. Identity and Auth for access need to be setup separately.
# Authors : sr229c@att.com , ea3935@att.com

ACR_NAME="20199devopsacr"
APP_RESOURCE_GROUP="sacce-eastus2-dev-app-rg-001"

# List all app service "webapp for containers" in the same resource group, 
# that need to be able to pull docker images from ACR
APP_NAMES_LIST=("sacce-dev-azapp-01" "sacce-dev-azapp-02") 

echo "Current list of Ips in ACR $ACR_NAME firewall rules :"
az acr show --query networkRuleSet.ipRules[].ipAddressOrRange --name $ACR_NAME

#Remove all existing old ips from ACR firewall
current_acr_ips=$(az acr show --query "networkRuleSet.ipRules[].ipAddressOrRange" --name $ACR_NAME -o tsv)

for ipAddr in $current_acr_ips;
do
    echo "Removing ${ipAddr}"
    echo "az acr network-rule remove -n ${ACR_NAME} --ip-address ${ipAddr}"
    az acr network-rule remove -n ${ACR_NAME} --ip-address ${ipAddr} 
done

az acr show --query networkRuleSet.ipRules[].ipAddressOrRange --name $ACR_NAME

echo "Done"

#Add all outbound Ips of app service to acr firewall list


for appName in "${APP_NAMES_LIST[@]}"
do
    echo "Setting firewall rules for ${appName} to access acr"
    app_outbound_ips=$(az webapp show --resource-group ${APP_RESOURCE_GROUP} --name ${appName} --query outboundIpAddresses -o tsv)

    echo $app_outbound_ips

    IFS="," 
    arr=($app_outbound_ips)
    for i in ${!arr[@]};
    do
        ipAddr=${arr[$i]}
        echo "Adding ${ipAddr}"
        az acr network-rule add -n ${ACR_NAME} --ip-address ${ipAddr} 
    done
    unset IFS

done

echo "Done"
echo "Current list of Ips in ACR $ACR_NAME firewall rules :"

az acr show --query networkRuleSet.ipRules[].ipAddressOrRange --name $ACR_NAME

