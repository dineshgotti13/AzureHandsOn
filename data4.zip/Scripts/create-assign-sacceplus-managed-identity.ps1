<#
This script creates a given managed identity (saccetrackingMI) for a given subscription, resource group if one does not exist previously.
Default values are for NPRD subscription. Assigns to 2nd app service (hosting SaccePlus app).
If the identity exists already, the script will exit, as even recreting that identity will change the client id. 
Usage: create-assign-sacceplus-managed_identity.ps1 -subscription 'xxx' -resourcegroup 'xxx' -identityname 'xxx' -appservicename 'xxx'

author : rb111y@att.com
#>

param(
[string]$subscription='08e07ad5-1ea1-4099-bb48-c11faa1dc236',
[string]$resourcegroup='sacce-eastus2-dev-app-rg-001',
[string]$identityname='saccetrackingMI',
[string]$appservicename='sacce-dev-azapp-02'
)

Write-Host ("Parameters passed are : " , $subscription, $resourcegroup)

$idnt=az identity show -g $resourcegroup -n $identityname --subscription $subscription  --query name
if ( $idnt -eq '"saccetrackingMI"'){
	Write-Host "Identity exists, not creating Managed Identity at this time !"
	exit 1
}
Write-Host "Creating Managed User Identity as it does not exist"
az identity create --resource-group $resourcegroup --name $identityname
Write-Host "Created Managed User Identity to web app"

# Get resource ID of the user-assigned identity
$resourceID=az identity show --resource-group $resourcegroup --name $identityname --query id --output tsv

# Get client ID of the user-assigned identity
$clientID=az identity show --resource-group $resourcegroup --name $identityname --query clientId --output tsv
Write-Host "Got client id Managed User Identity"

az webapp identity assign --resource-group $resourcegroup --name $appservicename --identities $resourceID --subscription $subscription
Write-Host "Assigned Managed User Identity to web app"