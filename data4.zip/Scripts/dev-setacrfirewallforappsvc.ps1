#Powershell Core

# Workaround to add outbound IPs of App service into the Allowed list of the ACR firewall 
# so that App service containerized webapps can pull images from the Azure Container registry.
# This is for connectivity only. Identity and Auth for access need to be setup separately.
# Authors : sr229c@att.com , ea3935@att.com

$ACR_NAME="20199devopsacr"
$APP_RESOURCE_GROUP="sacce-eastus2-dev-app-rg-001"

# List all app service "webapp for containers" in the same resource group, 
# that need to be able to pull docker images from ACR
$APP_NAMES_LIST="sacce-dev-azapp-01,sacce-dev-azapp-02"

& ./clear-all-ips-from-acr-firewall.ps1 $ACR_NAME

& ./add-appsvc-outip-to-acr-firewall.ps1 $ACR_NAME $APP_RESOURCE_GROUP $APP_NAMES_LIST



