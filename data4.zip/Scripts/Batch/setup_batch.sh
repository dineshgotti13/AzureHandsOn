#!/bin/bash

set -ex
export http_proxy=http://proxy.conexus.svc.local:3128
export https_proxy=http://proxy.conexus.svc.local:3128
export no_proxy=169.254.169.254,.vault.azure.net,.vaultcore.azure.net,.postgres.database.azure.com,.svc.local,.internal.cloudapp.net,localhost,127.0.0.0,.az.3pc.att.com,.azurecr.io

sudo cp -r /tmp/. /home/sacceadmin/

az login --i  



echo "--------------------Beginning of FileShare Mount--------------------"

cd /home/sacceadmin


STORAGE_SECRET=$(az keyvault secret show --vault-name ${KEYVAULT} --name ${STORAGE}-access-key --query "value"  -o tsv )
FILESHAREDIR="/mnt/${FILESHARE}"


echo "----Setting Credentials----"
if [ ! -d "/etc/smbcredentials" ]; then
    sudo mkdir "/etc/smbcredentials"
fi

smbCredentialFile="/etc/smbcredentials/${STORAGE}.cred"
if [ ! -f "/etc/smbcredentials/${STORAGE}.cred" ]; then
    echo username="${STORAGE}" | sudo tee $smbCredentialFile > /dev/null
    echo password="$STORAGE_SECRET" | sudo tee -a $smbCredentialFile > /dev/null
else 
    echo "----The credential file $smbCredentialFile already exists, and was not modified.----"
fi

sudo chmod 600 $smbCredentialFile

echo "----Mounting to FileShare----"
if [[ $(df -h | grep "${STORAGE}") = *$FILESHAREDIR* ]]; then
    echo "Mount already present"
else
    echo "Creating mount"
    mkdir -pv $FILESHAREDIR
    echo //"${STORAGE}".privatelink.file.core.windows.net/"${FILESHARE}" "$FILESHAREDIR" cifs nofail,vers=3.0,credentials="$smbCredentialFile",dir_mode=0777,file_mode=0777,serverino,uid=${USERID},gid=${USERID} | tee -a /etc/fstab
    sudo mount -t cifs //"${STORAGE}".privatelink.file.core.windows.net/"${FILESHARE}" "$FILESHAREDIR" -o vers=3.0,credentials="$smbCredentialFile",dir_mode=0777,file_mode=0777,serverino,uid=${USERID},gid=${USERID}
fi

echo "----Mount complete----"

echo "--------------------   End of FileShare Mount   --------------------"

echo "-----------------Beginning of Connect Direct Secure+----------------"
#
# Copyright 2018 AT&T Intellectual Property. All rights reserved.
#-----------------------------------------------------------------------------
# Project Name : Azure - Public cloud
# Support      : Send questions and/or issues to: hp541y@att.com, ak6179@att.com
# Description  : Install Connect Direct Secure+
# Usage        : ./connect_direct_intsall.sh
# Note         : This script should run as root user
#
#
# Requirements :
#    Run from any server where CD+ install is required.
#
#-----------------------------------------------------------------------------
# Revision History:
# 01/15/2021  hp541y/ak6179/hu177b Initial Version
#-----------------------------------------------------------------------------

## NODENAME(=hostname) has <=16 character limit, provide a meaningful name
CD_SECRET=$(az keyvault secret show --vault-name ${KEYVAULT} --name ${CD_KEY} --query "value"  -o tsv )
echo ${NODENAME}
cd /home/sacceadmin

echo "----Unzip application binaries----"
if [[ -f /home/sacceadmin/CC61JEN_IBM_CD_V6.1_UNIX_RedHat.tar ]]; then
  echo "File. Skip extracting unzip file"
else
  echo "Unzip Connect Direct file"
  sudo unzip "/home/sacceadmin/20199-sacceplusbatch-v1.0.4.zip" -d /home/sacceadmin
fi

echo "----Create ndm user----"
if [ ! -d /opt/app/ndm ]; then
  mkdir -pv /opt/app/ndm
  mkdir -pv /opt/app/ndm/CD_V6
  chmod -R 755 /opt/app/ndm
  chmod -R 755 /opt/app/ndm/CD_V6
fi

if grep -q ndm /etc/passwd
then
         echo "user ndm exists"
    else
         echo "USERID ndm does not exist - creating"
         if [ $(getent group ndm) ]; then
          echo "group exists."
          sudo useradd -g ndm -M -d /opt/app/ndm -s /bin/bash ndm
         else
          echo "group does not exist."
          sudo useradd -U -M -d /opt/app/ndm -s /bin/bash ndm
         fi
fi

if sudo grep -q ndm /etc/sudoers
then
         echo "user ndm exists"
    else
         echo "USERID ndm does not exist - Adding to /etc/sudoers"
         sudo echo "ndm     ALL=(ALL)       NOPASSWD: ALL" >> /etc/sudoers
fi

sudo chmod -R 755 /opt/app
sudo chown ndm:ndm /opt/app/ndm
sudo chown ndm:ndm /opt/app/ndm/CD_V6
sudo chmod 755 /opt/app/ndm
sudo chmod 755 /opt/app/ndm/CD_V6
sudo touch /opt/app/ndm/.profile
sudo chown ndm:ndm /opt/app/ndm/.profile
sudo su -c "cat << EOF | tee /opt/app/ndm/.profile
umask 022
NDMAPICFG=/opt/app/ndm/cdunix/ndm/cfg/cliapi/ndmapi.cfg
export NDMAPICFG
EOF
" - ndm
echo "${NODENAME}"

echo "----Untaring Binaries----"
sudo cp /home/sacceadmin/CC61JEN_IBM_CD_V6.1_UNIX_RedHat.tar /opt/app/ndm/CD_V6
cd /opt/app/ndm/CD_V6
if [[ -f /opt/app/ndm/CD_V6/cdinstall  ]]; then
  echo "Both files exists. Skip extracting tar file"
else
  echo "Untar Connect Direct tar file"
  sudo tar -xvf CC61JEN_IBM_CD_V6.1_UNIX_RedHat.tar
  sudo chown ndm:ndm cdinstall
  sudo chmod 744 cdinstall
  chown ndm:ndm /opt/app/ndm/CD_V6/*
  #sudo chown ndm:ndm CC61JEN_IBM_CD_V6.1_UNIX_RedHat.tar
  #sudo chmod 600 CC61JEN_IBM_CD_V6.1_UNIX_RedHat.tar
fi

#Run this script as a ndm user
echo "----Connect Direct Install----"
#sudo su -c 'echo -en "Y\n\n/opt/app/ndm/cdunix\nY\n1\n/opt/app/ndm/CD_V6/cdunix\nY\n\n3\n'${NODENAME}'\n\n\n\n\n\nY\nndm\n'${NODENAME}'\nndm\nn\nY\nndm\n\n5\n\nN" | sh /opt/app/ndm/CD_V6/cdinstall > CDinstall-log.txt' - ndm
sudo su -c "cat <<EOF | sh /opt/app/ndm/CD_V6/cdinstall > CDinstall-log.txt

/opt/app/ndm/cdunix
y
1
/opt/app/ndm/CD_V6/cdunix
y

3
${NODENAME}
1364
0.0.0.0
1363


y
ndm
${NODENAME}
ndm
n
y
ndm
y
y
${USERID}
y
n

1363

5

n
EOF
" - ndm

echo "script ran successfully.."
#echo -en "/opt/app/ndm/cdunix\n\n4\n\nY\nY\n5" | sudo /opt/app/ndm/cdunix/etc/cdcust > CD-configuring-root-permissions.txt
sudo su -c "cat <<EOF | sudo /opt/app/ndm/cdunix/etc/cdcust > CD-configuring-root-permissions.txt
/opt/app/ndm/cdunix

4

y
y
5
EOF
" - ndm

sudo ln -s /lib64/libtirpc.so.3 /lib64/libtirpc.so.1
export LD_LIBRARY_PATH=/opt/app/ndm/cdunix/ndm/lib

sudo su -c "cat <<EOF | tee /opt/app/ndm/cdunix/ndm/bin/cdstarta
#!/bin/sh
PATH=/usr/bin:/bin
HOST=${NODENAME}

umask 022
#ulimit -n 1024
/opt/app/ndm/cdunix/ndm/bin/cdpmgr -i /opt/app/ndm/cdunix/ndm/cfg/${NODENAME}/initparm.cfg
EOF
" - ndm
sudo chown ndm:ndm /opt/app/ndm/cdunix/ndm/bin/cdstarta
sudo chmod 744 /opt/app/ndm/cdunix/ndm/bin/cdstarta

# Create stop script
sudo su -c "cat <<EOF | tee /opt/app/ndm/cdunix/ndm/bin/cdstopa
#!/bin/sh
PATH=/usr/bin:/bin:/opt/app/ndm/cdunix/ndm/bin
NDMAPICFG=/opt/app/ndm/cdunix/ndm/cfg/cliapi/ndmapi.cfg
export NDMAPICFG
ndmcli -x << EOJ
stop;
EOJ
EOF
" - ndm

sudo chown ndm:ndm /opt/app/ndm/cdunix/ndm/bin/cdstopa
chmod 744 /opt/app/ndm/cdunix/ndm/bin/cdstopa

cat <<EOF | sudo tee > /etc/systemd/system/connectdirect.service
[Unit]
Description= starts and stops the Connect Direct service
After=syslog.target network-online.target

[Service]
Type=forking
ExecStart=/opt/app/ndm/cdunix/ndm/bin/cdstarta
Restart=no

[Install]
WantedBy=default.target
EOF

sudo cd /opt/app/ndm
echo "----Connect Direct Secure Plus Install----"
#sudo su -c 'echo -en "\nY\n\n/opt/app/ndm/cdunix\nY\nN\n5\n/opt/app/ndm/CD_V6/cdunix\nY\n\nY\n'${NODENAME}'\n'$CD_SECRET'\nN" | sh /opt/app/ndm/CD_V6/cdinstall > secureplus.txt' - ndm
sudo su -c "cat <<EOF | sh /opt/app/ndm/CD_V6/cdinstall > secureplus.txt

/opt/app/ndm/cdunix
y
n
5
/opt/app/ndm/CD_V6/cdunix
y

y
${NODENAME}
$CD_SECRET
n
EOF
" - ndm
sed -i '/netmap\.check/{n;s/proxy\.attempt=n/proxy\.attempt=y/}' /opt/app/ndm/cdunix/ndm/cfg/${NODENAME}/netmap.cfg

echo "KRSUBSYS@NDMATTA3:\\
  :local.id=${USERID}:\\
  :pstmt.upload=y:\\
  :pstmt.upload_dir=:\\
  :pstmt.download=y:\\
  :pstmt.download_dir=/opt/app/data:\\
  :pstmt.run_dir=:\\
  :pstmt.submit_dir=:\\
  :descrip=name phone:

KRSUBSYS@${APOCNODE}:\\
  :local.id=${USERID}:\\
  :pstmt.upload=y:\\
  :pstmt.upload_dir=:\\
  :pstmt.download=y:\\
  :pstmt.download_dir=/opt/app/data:\\
  :pstmt.run_dir=:\\
  :pstmt.submit_dir=:\\
  :descrip=name phone:

${USERID}:\\
  :admin.auth=n:\\
  :cmd.chgproc=y:\\
  :cmd.delproc=y:\\
  :cmd.flsproc=y:\\
  :cmd.selproc=y:\\
  :cmd.submit=y:\\
  :cmd.selstats=y:\\
  :cmd.stopndm=n:\\
  :cmd.trace=n:\\
  :pstmt.copy=y:\\
  :pstmt.runjob=y:\\
  :pstmt.runtask=y:\\
  :pstmt.submit=y:\\
  :snode.ovrd=y:\\
  :pstmt.copy.ulimit=y:\\
  :pstmt.upload=y:\\
  :pstmt.upload_dir=:\\
  :pstmt.download=y:\\
  :pstmt.download_dir=:\\
  :pstmt.run_dir=:\\
  :pstmt.submit_dir=:\\
  :name=:\\
  :phone=:\\
  :descrip=:
" >> /opt/app/ndm/cdunix/ndm/cfg/${NODENAME}/userfile.cfg

echo "NDMATTA3:\\
  :conn.retry.stwait=00.00.30:\\
  :conn.retry.stattempts=3:\\
  :conn.retry.ltwait=00.10.00:\\
  :conn.retry.ltattempts=6:\\
  :tcp.max.time.to.wait=180:\\
  :runstep.max.time.to.wait=0:\\
  :contact.name=:\\
  :contact.phone=:\\
  :descrip=:\\
  :sess.total=255:\\
  :sess.pnode.max=255:\\
  :sess.snode.max=255:\\
  :sess.default=1:\\
  :comm.info=NDMATTA3.ims.att.com;1364:\\
  :comm.transport=tcp:\\
  :comm.bufsize=65536:\\
  :pacing.send.delay=0:\\
  :pacing.send.count=0:

${APOCNODE}:\\
  :conn.retry.stwait=00.00.30:\\
  :conn.retry.stattempts=3:\\
  :conn.retry.ltwait=00.10.00:\\
  :conn.retry.ltattempts=6:\\
  :tcp.max.time.to.wait=180:\\
  :runstep.max.time.to.wait=0:\\
  :contact.name=:\\
  :contact.phone=:\\
  :descrip=:\\
  :sess.total=255:\\
  :sess.pnode.max=255:\\
  :sess.snode.max=255:\\
  :sess.default=1:\\
  :comm.info=${APOCFQDN};1364:\\
  :comm.transport=tcp:\\
  :comm.bufsize=65536:\\
  :pacing.send.delay=0:\\
  :pacing.send.count=0:
" >> /opt/app/ndm/cdunix/ndm/cfg/${NODENAME}/netmap.cfg

echo "----Configuring CDSecure+ with Certs----"

az keyvault secret download -e base64 -n "${CERTNAME}" --vault-name "${KEYVAULT}" -f "/home/sacceadmin/${CD_CERT_FQDN}.pfx" 
CERTPASS=$(az keyvault secret show --vault-name ${KEYVAULT} --name ${CERTNAME}-phrase --query "value"  -o tsv )
sudo openssl pkcs12 -in "/home/sacceadmin/${CD_CERT_FQDN}.pfx" -out "/home/sacceadmin/${CD_CERT_FQDN}.pem" -passin pass:"" -passout pass:"$CERTPASS"
sudo cp "/home/sacceadmin/${CD_CERT_FQDN}.pem" "/opt/app/ndm/cdunix/ndm/secure+/certificates/${CD_CERT_FQDN}.pem"
sudo chown ndm:ndm "/opt/app/ndm/cdunix/ndm/secure+/certificates/${CD_CERT_FQDN}.pem"

sudo su -c "cat <<REALEND | tee /opt/app/ndm/cdunix/ndm/bin/setupCDCert.sh
#!/bin/sh
sudo -u ndm /opt/app/ndm/cdunix/ndm/bin/spcli.sh << EOF
sync netmap 
    path=/opt/app/ndm/cdunix/ndm/cfg/${NODENAME}/netmap.cfg
    name=*;

Import KeyCert
    File=/opt/app/ndm/cdunix/ndm/secure+/certificates/${CD_CERT_FQDN}.pem
    Passphrase=$CERTPASS
    Label=${CD_CERT_FQDN}
    SyncNodes=y
    ImportMode=AddOrReplace;

Update LocalNode
    Protocol=TLS1.2
    SecurityMode=Disable
    Override=n
    keycertlabel=${CD_CERT_FQDN}
    AuthTimeout=120
    EncryptData=y
    ClientAuth=n
    CipherSuites=all
    SeaEnable=n
    SeaCertValDef=null;

display localnode;
q;
EOF

ps -ef | grep cdpmgr
sudo systemctl daemon-reload
sudo systemctl restart connectdirect
sudo systemctl status connectdirect.service

REALEND
" - ndm

sudo chown ndm:ndm /opt/app/ndm/cdunix/ndm/bin/setupCDCert.sh
chmod 744 /opt/app/ndm/cdunix/ndm/bin/setupCDCert.sh


echo "----CDSecure+ with Certs Completed----"

sudo systemctl daemon-reload
sudo systemctl restart connectdirect
sudo systemctl enable connectdirect
sudo systemctl start connectdirect.service
ps -ef | grep cdpmgr
sudo systemctl status connectdirect.service

echo "-----------------   End of Connect Direct Secure+   ----------------"

echo "--------------------Beginning of Crontab Scripts--------------------"

echo "----Creating Symlinks and needed directories----"

FILESHAREDIR="/mnt/${FILESHARE}"
echo $FILESHAREDIR

sudo mkdir -p $FILESHAREDIR/data $FILESHAREDIR/logs/fast $FILESHAREDIR/logs/batch/alarms $FILESHAREDIR/logs/batch/ERRORS $FILESHAREDIR/logs/batch/rm_file_TZP

if [[ -L "/opt/app/data" && -d "/opt/app/data" ]]; then
    echo "/opt/app/data is a symlink to a directory"
else
    sudo ln -s $FILESHAREDIR/data /opt/app/data
    sudo chown -h sacceadmin:sacceadmin /opt/app/data
fi

if [[ -L "/opt/app/logs" && -d "/opt/app/logs" ]]; then
    echo "/opt/app/logs is a symlink to a directory"
else
    sudo ln -s $FILESHAREDIR/logs /opt/app/logs
    sudo chown -h sacceadmin:sacceadmin /opt/app/logs
fi

# create log files to be read by LAW when updated
sudo echo "2021-08-05 19:54:38
TIMSsplit.pl|Beginning of error log file - ignore this alarm
" >> /opt/app/logs/batch/alarms/error.log
sudo echo "Logs for rm_file.sh:
-------------------------------------------------------------------
" >> /opt/app/logs/batch/rm_file_TZP/OldLogs.txt

echo "----Symlinks complete----"

sudo mkdir -p /home/sacceadmin/SCRIPT
cd /home/sacceadmin

echo "----Copy scripts into SCRIPT directory----"
sudo chmod -R 755 /home/sacceadmin/SCRIPT
# sudo cp -r /tmp/SCRIPT/. /home/sacceadmin/SCRIPT
sudo chmod -R 755 /home/sacceadmin/SCRIPT
sudo chown -R sacceadmin:sacceadmin /home/sacceadmin/SCRIPT

echo "----Run crontab install script----"
sudo chmod 755 crontab
sudo chown -R sacceadmin:sacceadmin crontab
sudo echo -e "KEYVAULT=${KEYVAULT}\n$(cat crontab)" > crontab
sudo cat /home/sacceadmin/crontab | crontab -
if [ ! -f "/usr/lib64/libpq.so.rh-postgresql12-5" ]; then
    sudo ln -s /opt/rh/rh-postgresql12/root/usr/lib64/libpq.so.rh-postgresql12-5 /usr/lib64/libpq.so.rh-postgresql12-5
else
    echo "postgresql12-5 already present"
fi

echo "----Configure rh-perl530 to run----"
if [ ! -f "/usr/lib64/libperl.so.rh-perl530-5.30" ]; then
    sudo ln -s /opt/rh/rh-perl530/root/usr/lib64/libperl.so.rh-perl530-5.30 /usr/lib64/libperl.so.rh-perl530-5.30
else
    echo "rh-perl530-5.30 already present"
fi
echo ". /opt/rh/rh-perl530/enable" >> ~/.bash_profile

echo "--------------------   End of Crontab Scripts   --------------------"

echo "--------------------   Start Docker and Dockerized App install     ---------------------"

#sudo yum install docker -y
#sudo mkdir -p /etc/systemd/system/docker.service.d

#sudo su -c "cat <<EOF | tee /etc/systemd/system/docker.service.d/http-proxy.conf
#[Service]
#Environment=\"HTTPS_PROXY=http://proxy.conexus.svc.local:3128\"
#Environment=\"HTTP_PROXY=http://proxy.conexus.svc.local:3128\"
#Environment=\"NO_PROXY=169.254.169.254,.vault.azure.net,.vaultcore.azure.net,.postgres.database.azure.com,.svc.local,.internal.cloudapp.net,localhost,127.0.0.0,.az.3pc.att.com,.azurecr.io\"

#EOF
#"
export http_proxy=http://proxy.conexus.svc.local:3128
export https_proxy=http://proxy.conexus.svc.local:3128
export no_proxy=169.254.169.254,.vault.azure.net,.vaultcore.azure.net,.postgres.database.azure.com,.svc.local,.internal.cloudapp.net,localhost,127.0.0.0,.az.3pc.att.com,.azurecr.io

sudo systemctl daemon-reload
sudo systemctl restart docker

az login --i
# pull the latest fastaccess docker image
az acr login --name ${ACR_NAME}
sudo docker pull ${DOCKER_IMAGE}

# Get TLS Cert from Keyvault and SAML_IDP_CERT
az keyvault secret download -e base64 -n "${FA_CERTNAME}" --vault-name "${KEYVAULT}" -f "/home/sacceadmin/${FA_CERT_FQDN}_1.pfx"
sudo openssl pkcs12 -in "/home/sacceadmin/${FA_CERT_FQDN}_1.pfx" -out "/home/sacceadmin/${FA_CERT_FQDN}.pem" -nodes -password pass:""
sudo openssl pkcs12 -export -out "/home/sacceadmin/${FA_CERT_FQDN}.pfx" -in "/home/sacceadmin/${FA_CERT_FQDN}.pem" -password pass:"$CERTPASS"
SAML_CERT=$(az keyvault secret show --vault-name ${KEYVAULT} --name saml-idp-cert --query "value"  -o tsv )

# setup env vars and files for fastaccess docker image SAML_IDP_CERT

sudo echo "
SSO_SERVER=${SSO_SERVER}
LOGOUT_URL=${LOGOUT_URL}
APP_SAML_CONFIG_FILE=${APP_SAML_CONFIG_FILE}
SAML_IDP_CERT=$SAML_CERT
APPURL=https://${FA_CERT_FQDN}
" >> /home/sacceadmin/fastaccess_env.list

# create server.xml for tomcat https setup

sudo echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<Server port=\"8005\" shutdown=\"SHUTDOWN\">
  <Listener className=\"org.apache.catalina.startup.VersionLoggerListener\" />
  <Listener className=\"org.apache.catalina.core.AprLifecycleListener\" SSLEngine=\"on\" SSLRandomSeed=\"builtin\"/>
  <Listener className=\"org.apache.catalina.core.JreMemoryLeakPreventionListener\" />
  <Listener className=\"org.apache.catalina.mbeans.GlobalResourcesLifecycleListener\" />
  <Listener className=\"org.apache.catalina.core.ThreadLocalLeakPreventionListener\" />
  <GlobalNamingResources>
    <Resource name=\"UserDatabase\" auth=\"Container\"
              type=\"org.apache.catalina.UserDatabase\"
              description=\"User database that can be updated and saved\"
              factory=\"org.apache.catalina.users.MemoryUserDatabaseFactory\"
              pathname=\"conf/tomcat-users.xml\" />
  </GlobalNamingResources>
  <Service name=\"Catalina\">
    <Connector port=\"80\" protocol=\"HTTP/1.1\"
               connectionTimeout=\"20000\"
               redirectPort=\"443\" />
    <Connector port=\"443\" protocol=\"org.apache.coyote.http11.Http11NioProtocol\"
               maxThreads=\"150\" scheme=\"https\" secure=\"true\" SSLEnabled=\"true\">
        <SSLHostConfig protocols=\"all\">
            <Certificate certificateKeystoreFile=\"ssl/sacce-fastaccess-edi-cert.pfx\"
                         certificateKeystorePassword=\"$CERTPASS\" certificateKeystoreType=\"PKCS12\"/>
        </SSLHostConfig>
    </Connector>
    <Engine name=\"Catalina\" defaultHost=\"localhost\">
      <Realm className=\"org.apache.catalina.realm.LockOutRealm\">
        <Realm className=\"org.apache.catalina.realm.UserDatabaseRealm\"
               resourceName=\"UserDatabase\"/>
      </Realm>

      <Host name=\"localhost\"  appBase=\"webapps\"
            unpackWARs=\"true\" autoDeploy=\"true\">
        <Valve className=\"org.apache.catalina.valves.AccessLogValve\" directory=\"logs\"
               prefix=\"localhost_access_log\" suffix=\".txt\"
               pattern=\"%h %l %u %t &quot;%r&quot; %s %b\" />
      </Host>
    </Engine>
  </Service>
</Server>
" >> /home/sacceadmin/server.xml

# create script for manual re-deployment of fast access

sudo echo "export http_proxy=http://proxy.conexus.svc.local:3128
export https_proxy=http://proxy.conexus.svc.local:3128
export no_proxy=169.254.169.254,.vault.azure.net,.vaultcore.azure.net,.postgres.database.azure.com,.svc.local,.internal.cloudapp.net,localhost,127.0.0.0,.az.3pc.att.com,.azurecr.io

az login --i 

# stop the existing service and remove the previous version of the docker image
docker stop fastaccess
docker rm fastaccess

# pull the latest fastaccess docker image
az acr login --name ${ACR_NAME}
sudo docker pull \"${DOCKER_IMAGE}\"

# run the service using the newly loaded image
sudo docker run -d \
-p 80:80 \
-p 443:443 \
--name fastaccess \
-v /home/sacceadmin/${FA_CERT_FQDN}.pfx:/usr/local/tomcat/ssl/sacce-fastaccess-edi-cert.pfx \
-v /home/sacceadmin/server.xml:/usr/local/tomcat/conf/server.xml \
-v /opt/app/data:/usr/local/tomcat/webapps/ROOT/WEB-INF/cgi/apps/krsubsys/data/ \
-v /opt/app/logs:/usr/local/tomcat/webapps/ROOT/WEB-INF/cgi/apps/krsubsys/logs/ \
--env-file /home/sacceadmin/fastaccess_env.list \
\"${DOCKER_IMAGE}\"
" >> /home/sacceadmin/fast_manual_deploy.sh

# make fast_manual_deploy.sh executable
sudo chmod +x fast_manual_deploy.sh

# run fastaccess 

sudo docker run -d \
-p 80:80 \
-p 443:443 \
--name fastaccess \
-v /home/sacceadmin/${FA_CERT_FQDN}.pfx:/usr/local/tomcat/ssl/sacce-fastaccess-edi-cert.pfx \
-v /home/sacceadmin/server.xml:/usr/local/tomcat/conf/server.xml \
-v /opt/app/data:/usr/local/tomcat/webapps/ROOT/WEB-INF/cgi/apps/krsubsys/data/ \
-v /opt/app/logs:/usr/local/tomcat/webapps/ROOT/WEB-INF/cgi/apps/krsubsys/logs/ \
--env-file /home/sacceadmin/fastaccess_env.list \
${DOCKER_IMAGE}

echo "--------------------    Done Docker and Dockerized App install     ---------------------"

