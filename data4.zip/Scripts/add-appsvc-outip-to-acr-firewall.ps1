#Powershell Core

# Workaround to add outbound IPs of App service into the Allowed list of the ACR firewall 
# so that App service containerized webapps can pull images from the Azure Container registry.
# This is for connectivity only. Identity and Auth for access need to be setup separately.
# Rerun this everytime App Service is created newly, scaled or any other activity that changes outbound IPs
# NOTE : Consider removing old ips from the ACR firewall first so that you dont leave unnecessary IPs behind from a previous run.
# Authors : sr229c@att.com , ea3935@att.com

$ACR_NAME=$args[0]
$APP_RESOURCE_GROUP=$args[1]

# List all app service "webapp for containers" in the same resource group, 
# that need to be able to pull docker images from ACR
$APP_NAMES_LIST=$args[2].split(",")


#Add all outbound Ips of app service to acr firewall list


foreach ($appName in $APP_NAMES_LIST) {
    Write-Output "Setting firewall rules for ${appName} to access acr"
    $app_outbound_ips=$(az webapp show --resource-group ${APP_RESOURCE_GROUP} --name ${appName} --query outboundIpAddresses -o tsv)
    $current_acr_ips=$(az acr show --query "networkRuleSet.ipRules[].ipAddressOrRange" --name $ACR_NAME -o tsv)

    Write-Output "App service outbound IPs = ${app_outbound_ips}"
    foreach ($ipAddr in $app_outbound_ips.split(",")) {        

        if( ($null -ne $current_acr_ips ) -and  ($current_acr_ips.contains($ipAddr)) ){
            Write-Output "Skipping - ${ipAddr} was already in list"           
        }
        else{
            Write-Output "Adding ${ipAddr}"
            az acr network-rule add -n ${ACR_NAME} --ip-address ${ipAddr} 
        }
    }
}

Write-Output "Done Adding Ips"
Write-Output "Current list of Ips in ACR $ACR_NAME firewall rules :"

az acr show --query networkRuleSet.ipRules[].ipAddressOrRange --name $ACR_NAME

Write-Output "Done"