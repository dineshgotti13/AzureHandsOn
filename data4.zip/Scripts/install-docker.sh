#!/bin/bash


# Bash script to install docker and startup fastaccess app (on Redhat 7 or Centos 7)

# Needed for downloading TLS cert of app from KV

CERTNAME=$1
KEYVAULT=$2
CERTFQDN=$3

###### Install Docker ######
sudo yum install docker
sudo mkdir -p /etc/systemd/system/docker.service.d

sudo echo "[Service] \\
Environment=\"HTTPS_PROXY=http://proxy.conexus.svc.local:3128\" \\
Environment=\"HTTP_PROXY=http://proxy.conexus.svc.local:3128\" \\ 
Environment=\"NO_PROXY=vault.azure.net,.vaultcore.azure.net,.svc.local,.internal.cloudapp.net,localhost,127.0.0.0,.az.3pc.att.com,.azurecr.io\" \\
" >> /etc/systemd/system/docker.service.d/http-proxy.conf

sudo systemctl daemon-reload
sudo systemctl restart docker

###### Startup latest docker image of App ######

# pull the latest fastaccess docker image

sudo docker pull 20199devopsacr.azurecr.io/fastaccess:latest

# setup env vars for fastaccess docker image

sudo echo "\\
SSO_SERVER=https://saml.stage.att.com/isam/sps/ATTIDPDefault/saml20/logininitial?RequestBinding=HTTPPost&PartnerId=\\
LOGOUT_URL=https://saml.stage.att.com/empsvcs/hrpinmgt/pagLogout\\
APP_SAML_CONFIG_FILE=FASTACCESS_DEV_SAML_Config.properties\\
" >> /tmp/fastaccess_env.list

# Get TLS Cert from Keyvault

az keyvault secret download -e base64 -n "${CERTNAME}" --vault-name "${KEYVAULT}" -f "/tmp/${CERTFQDN}.pfx" 

#TODO Setup TLS certificate for app in docker

# ------

# run fastaccess 

sudo docker run -d \
-p 80:80 \
-p 443:443 \
--name fastaccess \
-v /opt/app/data:/usr/local/tomcat/webapps/ROOT/WEB-INF/cgi/apps/krsubsys/data/ \
-v /opt/app/logs:/usr/local/tomcat/webapps/ROOT/WEB-INF/cgi/apps/krsubsys/logs/ \
--env-file /tmp/env.list \
20199devopsacr.azurecr.io/fastaccessedi:latest


