#Powershell Core


#Remove all existing old ips from ACR's firewall
# Authors : sr229c@att.com 

$ACR_NAME=$args[0]

Write-Output "Current list of Ips in ACR $ACR_NAME firewall rules :"
az acr show --query networkRuleSet.ipRules[].ipAddressOrRange --name $ACR_NAME

$current_acr_ips=$(az acr show --query "networkRuleSet.ipRules[].ipAddressOrRange" --name $ACR_NAME -o tsv)


foreach ($ipAddr in $current_acr_ips) {
    Write-Output "Removing ${ipAddr}"
    Write-Output "az acr network-rule remove -n ${ACR_NAME} --ip-address ${ipAddr}"
    az acr network-rule remove -n ${ACR_NAME} --ip-address ${ipAddr} 
}

az acr show --query networkRuleSet.ipRules[].ipAddressOrRange --name $ACR_NAME

Write-Output "Done Removing IPs"
