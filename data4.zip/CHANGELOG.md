# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## 2020-11-10

### Changed

The Kit and its layers now use MSI rather than SPN. Your ADO agent pool must have an MSI or the pipelines and layers will fail, complaining about authentication, missing service principal, etc. 

SPN support is DISABLED in this version of the kit and the associated layers. (the variables are commented out and/or removed) If you wish to use SPN, use an earlier version of the kit or modify/customize the scripts and the layers.

## [1.5.0] - 2020-11-04

### Changed

- Dynamic Storage Account SAS Uri for App Service Backup [#224132](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/224132)
- Dynamic Storage Account SAS Uri for App Service Logs [#224133](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/224133)

## [1.4.0] - 2020-10-14

### Added

- Added ACR password to appservice settings.[#209347](https://dev.azure.com/ATTDevOps/06a79111-55ca-40be-b4ff-0982bd47e87c/_workitems/edit/209347)

## [1.3.0] - 2020-09-04

### Added

- Integration of Application insights with appservice. [#171827](https://dev.azure.com/ATTDevOps/06a79111-55ca-40be-b4ff-0982bd47e87c/_workitems/edit/171827)
- Intergation of keyvault with Appservice. [#171828](https://dev.azure.com/ATTDevOps/06a79111-55ca-40be-b4ff-0982bd47e87c/_workitems/edit/171828)
- Integration of VNET with App service slot. [#176163](https://dev.azure.com/ATTDevOps/06a79111-55ca-40be-b4ff-0982bd47e87c/_workitems/edit/176163)

## [1.0.0] - 2020-08-12

### Added

- Initial Commit and added Appservice JumpStart Kit to Stratum
