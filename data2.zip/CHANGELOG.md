# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [3.0.0] - 2021-10-21
### Changed
- Layers now use Terraform 1.0 with azurerm provider 2.67
- Layers have replaced Terraform remote state lookups with tokenized strings
- Removed resources from privatednsrecords layer in favour of dns zone groups
### Added
- Layer execution arguments are named and will throw error if missing
- Terraform plan fails pipeline on error
- Windows vm layer now supports use of license_type argument, default set to use "hybrid license", specifically with the argument value = "Windows_Server". 

## [2.17.0] - 2021-08-17
### Added

- Added the ability to enable Terraform debugging [#668719](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/668719)

### Changed
- Altered the qetza task root directory so that users would not have to edit Layers.yaml

## [2.16.0] - 2021-07-14

### Added

- Added UDR layer and configuration content in tfvars files.

## [2.15.0] - 2021-06-07

### Added

- Added AMPLS layer and configuration content in tfvars files.

## [2.14.0] 2021-04-26

### Changed

- Modified README.md to identify centralized tokenization and the variables users need to change before use

## [2.13.0] - 2021-04-02

### Changed

- changed sql always on to false by default
- PE by default to ADO KV and SA. SqlAlwaysOn certificate at ADO KV, installation script at ADO SA

## [2.12.0] - 2021-04-01

### Changed

- added sql always on [446708](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_sprints/taskboard/CF%20DevOps%20Patterns%20Team/ATT%20Cloud/DevOps%20Pattern/Sprint%2016?workitem=446708)

## [2.11.0] - 2021-03-19

### Changed

- Resolve type mistakes in jumpstart-windows-vm kit [#480605](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/480605)

## [2.10.0] - 2021-03-08

### Changed

- Updated kit with new Windows VM layer - Removed Creation of managed disks and Disk encryption set from Windows VM layer.

## [2.9.0] - 2021-02-18

### Changed

- Code update in Jumpstart Windows VM Kit for new variables/tokens [#428115](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/428115)

## [2.8.0] - 2021-02-04

### Changed

- Stratum: run-command vm extensions is being added even if script path is null [#364847](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/364847)

## [2.7.0] - 2020-12-14

### Changed

- removed domainjoin layer, domain join will be handled with SCCM

## [2.6.0] - 2020-12-13

### Changed

- updated layer azsql to provide auditing_storage_account_name without dependency on failover group

## [2.5.0] - 2020-12-11

### Changed

- updated scripts: drivesetup and pagefile. Added if statement logic. If pagefile is set to Y drive scripts will not run

## [2.4.0] - 2020-12-11

### Changed

- updated readme file

## [2.2.0] - 2020-12-11

### Changed

- Add qetza.replacetokens task to Jumpstart-Windows-VM [#344592](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/344592)

## [2.1.0] 2020-12-07

### Changed

- VM layer: Update layer to support nics to be added to multiple backend pools [#236317](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/236317)

## [2.0.0] - 2020-11-19

### Changed

- The Kit and its layers now use MSI rather than SPN. Your ADO agent pool must have an MSI or the pipelines and layers will fail, complaining about authentication, missing service principal, etc.

- SPN support is DISABLED in this version of the kit and the associated layers. (the variables are commented out and/or removed) If you wish to use SPN, use an earlier version of the kit or modify/customize the scripts and the layers.

- Added variables for VM to reference existing disk encyrption set
  - use_existing_disk_encryption_set = false
  - existing_disk_encryption_set_name = null
  - existing_disk_encryption_set_rg_name = null

## [1.8.0] - 2020-11-02

updated domain join layer version in the pipeline

## [1.7.0] - 2020-10-20

added windows hostname upper case function

## [1.6.0] - 2020-10-14

- Enable Backup in AZ SQL Server [#194219](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/194219)
- Enable Auditing in AZ SQL Server [#194220](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/194220)
- Enable GEO Replication in AZ SQL Database [#194221](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/194221)
- Added SA and LAW Diagnostics settings for AZ SQL resource.
- Decoupled NSG resource from networking layer.
- Added multiple nic support to windows virtual machines.

### Changed

## [1.5.0] - 2020-10-05

### Changed

- updated layer sequence in windows jsk.

## [1.4.0] - 2020-09-28

### Changed

- Updated the domain join layer values to use the central key vault [200957](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/200957)

## [1.3.0] - 2020-09-28

### Changed

- Updated the domainjoin layer to 0.4.0 which uses msi to retrieve the Key Vault Secret.

## [1.2.0] - 2020-09-15

### Changed

- Resolve Multiple Layer Instance Issue In Layer.sh [#193412](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/193412)

## [1.1.0] - 2020-09-07

### Added

- WJSK: Implement custom extension script [#173452](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/173452)
- WJSK: Implement Back up recovery [#173455](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/173455)
- WJSK: Implement Load balancer [#173454](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/173454)
