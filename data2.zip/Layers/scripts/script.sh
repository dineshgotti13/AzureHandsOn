##  THIS SCRIPT IS FOR CONFIGURING IP FORWARDER ON UBUNTU VM AS PER THE DOCUMENT https://dev.azure.com/ATTDevOps/ATT%20Cloud/_wiki/wikis/ATT-Cloud.wiki/1742/Microsoft-SQL-Azure-Network-Connectivity-Guidance
## pass below parameters for the script to execute – EXAMPLES Shown Below
#frontend_port=1433
#sql_mi_ip=10.0.3.254

sysctl net.ipv4.ip_forward=1
iptables -t nat -A PREROUTING -p tcp --dport 1433 -j DNAT --to-destination 10.0.3.254:1433
iptables -t nat -A POSTROUTING -j MASQUERADE