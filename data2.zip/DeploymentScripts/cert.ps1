<#
Install and Configure SMTP server or MTA (Mail Transfer Agent) on Windows

Requirements:
1. Upload the certificate for the MTA in Azure Keyvault [ this is required to setup TLS ]
2. Password for the certificate also needs to be uploaded to Keyvault.
3. The SMTP FQDN should point to the SMTP TLS Cluster smtptls.it.att.com  . To do this create a DNS A record pointing to the NVA Private Endpoint IP Address.

Functionality:
Configures SMTP to send emails 

Sample Run: 
./smtp_mtaDeploy.ps1 -KeyVaultName "cvs-eastus2-prod-kv-02" -CertificateSecretName "npaz-seba1-cert" -smtpCertSecretName "certificatepassword" -vnetIPaddress = "10.254.157.0" -subnetMask = "255.255.255.0" -iisWebsiteNamePrefix = "paz-seba1" -iisWebsiteNameDomain = "it.att.com"

#>


param(
  [string]$KeyVaultName          = $(throw "KeyVaultName is required"),
  [string]$smtpCertName          = $(throw "smtpCertName is required"),
  [string]$smtpCertSecretName    = $(throw "CertificateSecretName is required"),
  [string]$subnetMask            = $(throw "subnetMask is required (255.255.255.0)")
)

$vnetIPaddress=((Get-NetIPAddress -AddressFamily IPv4)| Where-Object { $_.IPAddress -like '10.*' }).IPAddress

#####################################################################################################
# Set Variables
#####################################################################################################
Write-Output "Started smtpDeploy.ps1 $(Get-Date)"

$homeDirectory                  = "E:\deployment-smtp-mta"
$logFileName                    = "smtp_mta-$(Get-Date -Format "yyyy_MM_dd_HH_mm").txt"
$certificatePath                = "E:\\Certificates\\$env:computername.az.3pc.att.com.pfx"

#####################################################################################################
# Execute prerequisites
#####################################################################################################
Write-Output "Clean and Create Home Directory: $homeDirectory"
Get-ChildItem $homeDirectory -Recurse -Force | Remove-Item -Recurse -Force
New-Item -Path $homeDirectory -Type Directory -ErrorAction SilentlyContinue
Set-Location -Path $homeDirectory
Start-Transcript -Path "$homeDirectory\$logFileName"

#####################################################################################################
# Get Secrets/Certificates from KeyVault
#####################################################################################################   
Write-Output "Get MSI Key Vault Token"
$kvtoken=(Invoke-RestMethod -Headers @{Metadata="true"} -Method GET -Uri "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net").access_token
$kvheaders = @{ "Authorization" = "Bearer $kvtoken"; "x-ms-version" = "2017-11-09" }
$certpassword=(Invoke-RestMethod -Method GET -Headers $kvheaders -Uri https://$KeyVaultName.vault.azure.net/secrets/${smtpCertSecretName}?api-version=2016-10-01).value
$base64Certificate=(Invoke-RestMethod -Method GET -Headers $kvheaders -Uri https://$KeyVaultName.vault.azure.net/secrets/${smtpCertName}?api-version=2016-10-01).value # content -split "("")"
$bytes = [Convert]::FromBase64String($base64Certificate)
$certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
$certCollection.Import($bytes,$certpassword,[System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
$protectedCertificateBytes = $certCollection.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12, $certpassword)
New-Item -Path "E:\Certificates" -Type Directory -ErrorAction SilentlyContinue
[System.IO.File]::WriteAllBytes($certificatePath, $protectedCertificateBytes)
$SecurePassword = $certpassword | ConvertTo-SecureString -AsPlainText -Force
Import-PfxCertificate -FilePath $certificatePath -CertStoreLocation Cert:\LocalMachine\My -Password $SecurePassword -Exportable

# #####################################################################################################
# # Check if SMTP is installed before installing it.
# #####################################################################################################
# $smtp = Get-WindowsFeature "smtp-server"
# if (!$smtp.Installed) {
#   Write-Host "SMTP is not installed, installing it..." -ForegroundColor Red
#   Install-WindowsFeature -Name SMTP-Server -IncludeAllSubFeature -IncludeManagementTools
#   Add-WindowsFeature Web-WMI, Web-Mgmt-Console
# }

# #####################################################################################################
# # Ensure that SMTP service is UP and running
# #####################################################################################################
# Write-Host -Foregroundcolor White " Starting SMTP service..."
# Start-Service "SMTPSVC" -ErrorAction SilentlyContinue
# if ($?) {
#   Write-Host -Foregroundcolor Green " [OK] Service successfully started."
# }
# else {
#   Write-Host -Foregroundcolor Red " [Error] Unable to start service."
#   Exit
# }

# #####################################################################################################
# # Set startup type to Automatic for SMTP service
# #####################################################################################################
# Write-Host -Foregroundcolor White " Changing the start-up type of SMTP service to 'Automatic'..."
# Set-Service "SMTPSVC" -StartupType Automatic -ErrorAction SilentlyContinue
# if ($?) {
#   Write-Host -Foregroundcolor Green " [OK] Successfully changed startup type."
# }
# else {
#   Write-Host -Foregroundcolor Red " [Error] Unable to change startup type."
#   Exit
# }

# #####################################################################################################
# # Update SMTP port Binding Port to 2500 <optional> <In case port is other than 25>
# #####################################################################################################
# $Serverbindings = (gwmi -namespace root\microsoftiisv2 -class iissmtpserversetting)
# $Bindings = $ServerBindings.ServerBindings
# foreach ($Binding in $bindings) {
#   $Binding.Port = "25"
# } 
# $Serverbindings.ServerBindings = $Bindings
# $ServerBindings.Put()

# #####################################################################################################
# # Define Function to configure the Default domain
# #####################################################################################################
# function Configure-SMTPService ([string]$DomainName, [bool]$configureDomain) {
#   if ($configureDomain -eq $false) {
#     Exit
#   }
#   New-Item -Path "E:\mailroot" -Type Directory -ErrorAction SilentlyContinue
	   
#   Write-Host -Foregroundcolor White " Configuring virtual SMTP server..."
#   try {
#     $ipBlock=@(24,0,0,128,32,0,0,128,80,0,0,128,88,0,0,128,1,0,0,0,96,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,1,0,0,0,2,0,0,0,2,0,0,0,3,0,0,0,0,0,0,0,100,0,0,128,2,0,0,0,1,0,0,0,4,0,0,0,0,0,0,0,96,0,0,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,255,255)
#     $ipList = @()
#     $ipOctet = @()

#     $ipList = $vnetIPaddress
#     $ipOctet += $ipList.Split(".")
#     $subnetOctet += $subnetMask.Split(".")
#     $ipBlock += $subnetOctet
#     $ipBlock += $ipOctet

#     $virtualSMTPServer = Get-WmiObject IISSmtpServerSetting -namespace "ROOT\MicrosoftIISv2" | Where-Object { $_.name -like "SmtpSVC/1" }
#     $virtualSMTPServer.BadMailDirectory = 'E:\mailroot\Badmail'
#     $virtualSMTPServer.QueueDirectory = 'E:\mailroot\Queue'
#     $virtualSMTPServer.PickupDirectory = 'E:\mailroot\Pickup'
#     $virtualSMTPServer.DropDirectory = 'E:\mailroot\Drop'
#     $virtualSMTPServer.AllowAnonymous = 'true'
#     $virtualSMTPServer.DefaultDomain = "$DomainName"
#     $virtualSMTPServer.FullyQualifiedDomainName = "$DomainName"
#     $virtualSMTPServer.DoMasquerade = 'True'
#     $virtualSMTPServer.MasqueradeDomain = "$DomainName"
#     $virtualSMTPServer.RouteAction = '4'
#     $virtualSMTPServer.SmartHost = 'smtptls.it.att.com'
#     $virtualSMTPServer.LogExtFileFlags = '1345252'
#     $virtualSMTPServer.LogExtFileComputerName = 'True'
#     $virtualSMTPServer.LogExtFileTime = 'False'
#     $virtualSMTPServer.LogType = '1'
#     $virtualSMTPServer.RelayForAuth = '-1'
#     $virtualSMTPServer.SmartHostType = '2'
#     $virtualSMTPServer.RelayIpList = $ipblock
            
#     # Set maximum messages per connection
#     $virtualSMTPServer.MaxBatchedMessages = 0
#     $virtualSMTPServer.Put() | Out-Null
#     Write-Host -Foregroundcolor Green " [OK] Successfully configured virtual SMTP server."
#   }
#   catch {
#     Write-Host -Foregroundcolor Red " [Error] Unable to configure virtual SMTP server."
#     # Exit
#   }
# }

# #####################################################################################################
# # Define Function to configure the Alias domain
# #####################################################################################################
# function Configure-SMTPService-Alias ([string]$AliasEmailDomainName, [bool]$configureAliasDomain) {
#   #Skip to create a domain alias if false
#   if ($configureAliasDomain -eq $false) {
#     Exit
#   }
      
#   Write-Host -Foregroundcolor White " Creating incoming SMTP domain..."
      
#   # First create a new smtp domain. The path 'SmtpSvc/1' is the first virtual SMTP server. If you need to modify another virtual SMTP server
#   # change the path accordingly.
#   try {
#     $smtpDomains = [wmiclass]'root\MicrosoftIISv2:IIsSmtpDomain'
#     $newSMTPDomain = $smtpDomains.CreateInstance()
#     $newSMTPDomain.Name = "SmtpSvc/1/Domain/$AliasEmailDomainName"
#     $newSMTPDomain.Put()  | Out-Null
#     Write-Host -Foregroundcolor Green " [OK] Successfully created incoming email domain."
#   }
#   catch {
#     Write-Host -Foregroundcolor Red " [Error] Unable to create incoming email domain."
#     Exit
#   }
      
#   Write-Host -Foregroundcolor White " Configuring incoming SMTP domain..."
      
#   try {
#     # Configure the new smtp domain as alias domain
#     $smtpDomainSettings = [wmiclass]'root\MicrosoftIISv2:IIsSmtpDomainSetting'
#     $newSMTPDomainSetting = $smtpDomainSettings.CreateInstance()
 
#     # Set the type of the domain to "Alias"
#     $newSMTPDomainSetting.RouteAction = 16
 
#     # Map the settings to the domain we created in the first step
#     $newSMTPDomainSetting.Name = "SmtpSvc/1/Domain/$AliasEmailDomainName"
#     $newSMTPDomainSetting.Put() | Out-Null
#     Write-Host -Foregroundcolor Green " [OK] Successfully configured incoming email domain."
#   }
#   catch {
#     Write-Host -Foregroundcolor Red " [Error] Unable to configure incoming e-mail domain."
#     Exit
#   }
       
# }


# #####################################################################################################
# # Main code, Invoke the function to configure the default domain and the alias
# #####################################################################################################
# Configure-SMTPService "$env:computername.az.3pc.att.com" $true
# Configure-SMTPService-Alias "$env:computername.az.3pc.att.com" $true


# Write-Output "Finished smtpDeploy.ps1 $(Get-Date)"
# Stop-Transcript

# Exit 0